//Not Yet Fixed
// ************************************************
// BaseConvert.java
//
// Converts base 10 numbers to another base
// (at most 4 digits in the other base). The
// base 10 number and the base are input.
// ************************************************
import static java.lang.System.out;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.lang.Math;
public class Lab2point3E
{
    public static void main (String[] args)
    {
    int base;
// the new base
    int base10Num;
// the number in base 10
    int maxNumber; // the maximum number that will fit
// in 4 digits in the new base
    int place0r; // digit in the 1's (base^0) place
    int place1r; // digit in the base^1 place
    int place2r; // digit in the base^2 place
    int place3r; // digit in the base^3 place
    int place0q, place1q, place2q, place3q, cake;
// read in the base 10 number and the base
    System.out.println();
    System.out.println ("Base Conversion Program");
    System.out.println();
    base = GetInfoV4.getSlider("Please enter a base (2 - 9): ", 2, 9 );
    
    
// Compute the maximum base 10 number that will fit in 4 digits
    maxNumber = (int) ((Math.pow(base, 4)) - 1); 
    base10Num = GetInfoV4.getSlider("Please enter a base 10 number to convert: ", 0,(int)maxNumber);
    
    cake = base - 1;
    
    place0q = base10Num / base;
    place0r = base10Num % base;
    place1q = place0q / base;
    place1r = place0q % base;
    place2q = place1q / base;
    place2r = place1q % base;
    place3q = place2q / base;
    place3r = place2q % base;
  
    String baseBNum = new String ("The base10 number "+base10Num+" converted to base" + base + " is : " + place3r + place2r + place1r + place0r ); // the number in the new base
    String maxBNum = new String ("\nThe max base" + base + " number is : " +cake+cake+cake+cake);
    String work = "\n";
    work += (baseBNum);
    work += (maxBNum);
    GetInfoV4.showMessage(work);
    }
}


