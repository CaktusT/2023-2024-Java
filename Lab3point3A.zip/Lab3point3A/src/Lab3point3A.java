// ****************************************************
// Salary.java
//
// Computes the amount of a raise and the new
// salary for an employee. The current salary
// and a performance rating (a String: "Excellent",
//"Good" or "Poor") are input.
// ***************************************************************
import static java.lang.System.out;
import java.text.DecimalFormat;
import java.text.NumberFormat;
class Lab3point3A
{
    public static void main (String[] args)
    {
        double currentSalary; // employee's current salary
        double raise = 1;  // amount of the raise
        double newSalary;
        String rating;
        // new salary for the employee
        // performance rating
        currentSalary = GetInfoV4.getDouble("**NO DOLLAR SIGN** ie : 1000 \n Enter the current salary: ");
        
        rating = GetInfoV4.getString("""
                                     **IF A CORRECT RATING IS NOT GIVEN THE RAISE WILL NOT BE EFFECTED **
                                     Enter the performance rating (Excellent, Good, or Poor): """);
        var bread = rating.equalsIgnoreCase("Excellent");
        var pizza = rating.equalsIgnoreCase("Good");
        var cheese = rating.equalsIgnoreCase("poor");
        String work = ("\n");
                
            if(bread == true)
            {
                out.println("good");  raise = 1.06;

            }
            else
                if(pizza == true)
                {
                 
                   
                   raise = 1.04;
                }
                   else 
                        if(cheese == true)
                        {            
                            raise = 1.015;

                        }
                        else
                        {
                            
                            work+= ("You have not entered a correct performance rating. You are not reciving a raise.\n");
                            raise = 1;
                        }

       
         
            
        
        // Compute the raise using if ...
        newSalary = currentSalary * raise;
        // Print the results
        NumberFormat money = NumberFormat.getCurrencyInstance();
        
        work += ("Your new salary is : ");
        work += money.format(newSalary);

        GetInfoV4.showMessage(work);
        // Print out using GetInfoV4 the Current Salary, the raise, and
        // the New Salary
    }
}