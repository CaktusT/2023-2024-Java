//******************************************
// PlusTest.java
//
// Demonstrate the different behaviors of
// the + operator
//******************************************
public class Lab2point1C
{
// ------------------------------------
// main prints some expressions using
// the + operator
// -------------------------------------
public static void main (String[] args)
    {
    System.out.println ("This is a long string that is the " +
    "concatenation of two shorter strings.");
    System.out.println ("The first computer was invented about" +
    55 + "years ago.");
    //line 17 + 18 could be less "scrunched up" if the programmer were to put a " " after about in the first string and another " " before the second string
    
    
    System.out.println ("8 plus 5 is " + 8 + 5);
    //line 21 works from left to right, ie : "8 plus 5 is " 8, after that the 5 is put on the end
    System.out.println ("8 plus 5 is " + (8 + 5));
    //Line 23 works with pemdas paranthesis first so "(8+5) = 13" then puts "13" on the end of "8 plus 5 is " making it "8 plus 5 is 13" 
    System.out.println (8 + 5 + " equals 8 plus 5.");
    //line 25 works from left to right where it does "8 + 5" first then puts the 13 on the end of " equals 8 plus 5."
    System.out.println ( "Ten robins plus " + ( 10+3 ) + " canaries is 23 birds.");
    System.out.println ( "Ten robins plus 13 canaries is 23 birds.");
    }
}