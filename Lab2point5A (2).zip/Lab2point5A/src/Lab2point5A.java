// ***************************************************************
// StringManips.java
//
// Test several methods for manipulating String objects
// ***************************************************************ystem.out;
import static java.lang.System.out;
import java.text.DecimalFormat;
import java.text.NumberFormat;
class Lab2point5A
{
    public static void main (String[] args)
    {
        String phrase = new String ("This is a String test.");
        int phraseLength; // number of characters in the phrase String
        int middleIndex;
        int number;
        String middle3;
        String firstHalf; // first half of the phrase String
        String secondHalf; // second half of the phrase String
        String switchedPhrase; // a new phrase with original halves switched
        // compute the length and middle index of the phrase
        phraseLength = phrase.length();
        number = (phraseLength - 3)/2;
        middleIndex = phraseLength / 2;
        // get the substring for each half of the phrase
        middle3 = phrase.substring(10 , 22-number );
        firstHalf = phrase.substring(0,middleIndex);
        secondHalf = phrase.substring(middleIndex, phraseLength);
        // concatenate the firstHalf at the end of the secondHalf
        switchedPhrase = secondHalf.concat(firstHalf);
        switchedPhrase = switchedPhrase.replace(" ", "*");
        // print information about the phrase
        String work = ("\n");
        work +=  ("                  INITAL LAB");
        work +=  ("\nOriginal phrase: " + phrase);
        work +=  ("\nLength of the phrase: " + phraseLength + " characters");
        work +=  ("\nIndex of the middle: " + middleIndex);
        work +=  ("\nCharacter at the middle index: " + phrase.charAt(middleIndex));
        work +=  ("\nMiddle 3 characters: " + middle3);
        work +=  ("\nSwitched phrase: " + switchedPhrase);
        GetInfoV4.showMessage(work);
        String city = GetInfoV4.getString("What city do you live in");
        String state = GetInfoV4.getString("What state do you live in");
        String upperState = state.toUpperCase();
        String lowerCity = city.toLowerCase();
        String con = upperState.concat(lowerCity);
        String con2 = con.concat(upperState);
        String bread = ("\n");
        bread +=  ("             Part 3 + 4 of LAB 2.5 : \n");
        bread += (con2);
        GetInfoV4.showMessage(bread);
    }
}