import java.util.Random;
import static java.lang.System.out;
class Lab2point5C
{
    public static void main (String[] args)
    {
        Random gen = new Random();
        int di1, di2, totalr;
        String work = ("\n");
        di1 = gen.nextInt(6) + 1;
        work += ("On dice one you rolled a(n) : " + di1);
        
        di2 = gen.nextInt(6) + 1;
        work +=("\nOn dice two you rolled a(n) : " + di2);
        
        totalr = di1 + di2; 
        
        GetInfoV4.showMessage(work + "\nYour total number you rolled is : " + totalr); 
        
    }
}