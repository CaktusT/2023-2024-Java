//*************************************************
//File: Lab2point3C.java
//*************************************************
import static java.lang.System.out;
import java.lang.Math;
import java.text.NumberFormat;
import java.text.DecimalFormat;

public class Lab2point3C
{
    public static void main(String[] args)
    {
        final int FINCH = 5; //5lb / in female
        final int MINCH = 6; //6lb / in male
        final double MINPER = 0.85;
        final double MAXPER = 1.15;
        final int FWEIGHT = 100;
        final int MWEIGHT = 106;
        int mHeight, fHeight, totalHeight, weightF, weightM;
        double rangeHM, rangeLM, rangeHF, rangeLF;
        int heightft = GetInfoV4.getSlider ("What is your height (ft)",4,8);  
        int heightin = GetInfoV4.getSlider("What is height(in)",0,11);
        DecimalFormat bread = new DecimalFormat("0.##");
        
        totalHeight = (heightft*12) + heightin; 
        
        mHeight = totalHeight - 60; 
        fHeight = totalHeight - 60; 
        
        weightF = (fHeight*FINCH) + FWEIGHT;
        weightM = (mHeight*MINCH) + MWEIGHT;
        
        rangeHM = weightM * MAXPER;
        rangeLM = weightM * MINPER;
        
        rangeHF = weightF * MAXPER;
        rangeLF = weightF * MINPER;
        
        System.out.println ("The ideal weight for a female is from : " + bread.format(rangeLF) + " to " + bread.format(rangeHF) + " lbs.");
        System.out.println ("The ideal weight for a male is from : " + bread.format(rangeLM) + " to " + bread.format(rangeHM) + " lbs.");
            
        
            
  
    }
}