public class Lab2point1B
{
    
    public static void main (String[] args)
    {
       
        
        int lab1 = 43;
        int lab2 = 50;
        int lab3 = 39;
        int lab4 = 40;
        int lab5 = 28;
        int bonus1 = 7;
        int bonus2 = 8;
        int bonus3 = 10;
        int b4 = 6; 
        int b5 = 4;
        int total1 = lab1 + bonus1;
        int total2 = lab2 + bonus2;
        int total3 = lab3 + bonus3;
        int t4 = lab4 + b4;
        int t5 = lab5 + b5; 
        System.out.println ("\t///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
	System.out.println ("\t==          Student Points          ==");
        System.out.println ("\t\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////");

        System.out.println ("\tName\t\tLab\tBonus\tTotal");
        System.out.println ("\t----\t\t---\t-----\t-----");
        System.out.println ("\tJoe\t\t"+lab1+"\t"+bonus1+"\t"+total1);
        System.out.println ("\tWilliam\t\t"+lab2+"\t"+bonus2+"\t"+total2);
        System.out.println ("\tMary Sue\t"+lab3+"\t"+bonus3+"\t"+total3);
        System.out.println ("\tBen\t\t"+lab4+"\t"+b4+"\t"+t4);
        System.out.println ("\tJaedyn\t\t"+lab5+"\t"+b5+"\t"+t5);
        System.out.println ();
    }
}
