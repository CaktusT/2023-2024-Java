//*************************************************
//File: Lab2point3B.java
//Purpose: Determine how much paint is needed to
//paint the walls of a room given its length,
//width, and height
//*************************************************
import static java.lang.System.out;
import java.lang.Math;
import java.text.NumberFormat;
import java.text.DecimalFormat;

public class Lab2point3B
{
    public static void main(String[] args)
    {
        final int COVERAGE = 350; //paint covers 350 sq ft/gal
        double totalSqFt;
        double paintNeeded;
        int length = GetInfoV4.getInt ("What is the length of the room (ft)");  
        int width = GetInfoV4.getInt("What is the width of the room (ft)");
        int height = GetInfoV4.getInt("What is the hight of the room (ft)");
        int doors = GetInfoV4.getInt("How many doors are there in the room");
        int windows = GetInfoV4.getInt("How many windows are there in the room");
        
        
        totalSqFt = ((length*2) + (width*2))*height;
        
        
        paintNeeded = ((totalSqFt - (windows*15) - (doors*20)) / COVERAGE);
        
        
        System.out.println("The Length is : " + length + "ft");
        System.out.println("The Width is : " + width + "ft");
        System.out.println("The Height is : " + height + "ft");
        System.out.println("The amount of windows is : " + windows );
        System.out.println("The amount of doors is : "  + doors);
        System.out.println (Math.ceil(paintNeeded) + " Gallons of paint is needed to paint the whole room");
        
        
        //Compute the amount of paint needed
        //Print the length, width, and height of the room
        //and the number of gallons of paint needed.
    }
}