//*********************************************************
//   Lab2point1A.java
//
//   Prints a list of student names with their hometowns
//   and intended major
//***********************************************************
public class Lab2point1A
{
    // ------------------------
    // main prints the list
    // ------------------------
    public static void main (String[] args)
    {
	System.out.println ();
	System.out.println ("\tName\t\tHometown\t\tMajor");
	System.out.println ("\t====\t\t========\t\t========");
	System.out.println ("\tSally\t\tRoanoke\t\t\tComputer Science");
	System.out.println ("\tAlexander\tWashington\t\tMath");
        System.out.println ("\tBen\t\tEast Meadow\t\tComputer Science");
        System.out.println ("\tJaedyn\t\tEast Meadow\t\tPhysical Therapy");
        System.out.println ("\tTyler\t\tEast Meadow\t\tComputer Science");
	System.out.println ();
    }
}
