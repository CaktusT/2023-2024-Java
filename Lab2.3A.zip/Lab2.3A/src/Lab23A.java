//*********************************************************
// Circle.java
//
// Print the area of a circle with two different radii
//*********************************************************
import java.text.DecimalFormat;

class Circle
{
    public static void main(String[] args)
    {
    final double PI = 3.14159;
    int radius; 
    DecimalFormat bread = new DecimalFormat("0.##");
    
    radius = GetInfoV4.getInt("Please enter a value for the radius. ");
    double area1 = PI * radius * radius;
    double cric1 = 2 *(PI * radius);
    System.out.println("The area of a circle with radius " + bread.format(radius) +
    " is " + bread.format(area1));
    System.out.println("The circumference of a circle with radius " + bread.format(radius) +
    " is " + bread.format(cric1));
    int radius2 = radius*2;
    double area2 = PI * radius2 * radius2;
    double cric2 = 2 *(PI * radius2);
    System.out.println("The area of a circle with radius " + bread.format(radius2) +
    " is " + bread.format(area2));
    System.out.println("The circumference of a circle with radius " + bread.format(radius2) +
    " is " + bread.format(cric2));
    
    double areachange = area2 / area1;
    System.out.println("The area changed by a factor of " + bread.format(areachange));
    
    double circchange = cric2 / cric1;
    System.out.println("The circumference changed by a factor of " + bread.format(circchange));

    
    }
}